# PyQt5 代码结构模板
from PyQt5.Qt import *
from resourse.register import Ui_Form


class RegisterPane(QWidget, Ui_Form):
	exit_signal = pyqtSignal()
	register_signal=pyqtSignal(str,str)

	def __init__(self,parent=None,*args,**kwargs):
		super().__init__(parent,*args,**kwargs)  # 用于继承父类
		self.setAttribute(Qt.WA_StyledBackground, True)
		self.setupUi(self)
		# self.setWindowFlags(Qt.FramelessWindowHint)  # 隐藏介面头部

	def register(self):
		ac_txt = self.accunt_le.text()
		pw_txt = self.password_le.text()
		self.register_signal.emit(ac_txt,pw_txt)

	def about(self):
		QMessageBox.about(self, '说明', '这是我用python写的第一个程序（^_^）')

	def reset_re(self):
		self.accunt_le.clear()
		self.password_le.clear()
		self.confrim_pw_le.clear()

	def enable_register(self):
		ac_txt = self.accunt_le.text()
		pw_txt = self.password_le.text()
		cpw_txt = self.confrim_pw_le.text()
		if len(ac_txt) > 0 and len(pw_txt) > 0 and len(cpw_txt) > 0 and pw_txt == cpw_txt:
			self.pushButton.setEnabled(True)
		else:
			self.pushButton.setEnabled(False)

	def exit_re(self):
		self.close()
		self.exit_signal.emit()

	def mousePressEvent(self, even):
		if even.button() == Qt.LeftButton:
			self.m_drag = True
			self.m_DragPosition = even.globalPos() - self.pos()
			even.accept()
			self.setCursor(QCursor(Qt.OpenHandCursor))


if __name__ == '__main__':
	import sys

	app = QApplication(sys.argv)

	window = RegisterPane()
	window.exit_signal.connect(lambda: print('退出了'))
	window.register_signal.connect(lambda a,p:print(a,p))
	window.show()

	sys.exit(app.exec_())
