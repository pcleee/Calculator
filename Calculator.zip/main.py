from login_pane import LoginPane
from register_pane import RegisterPane
from calculator_pane import CalculatorPane

from PyQt5.Qt import *



if __name__ == '__main__':
	import sys

	app = QApplication(sys.argv)
	calculator_p=CalculatorPane()

	login_pane = LoginPane()
	def show_registerpane():
		register_pane=RegisterPane(login_pane)
		register_pane.move(0,0)
		register_pane.show()

	def goto_cal():
		calculator_p.show()
		login_pane.hide()

	login_pane.gotocal.connect(goto_cal)
	login_pane.show_register_pane.connect(show_registerpane)
	login_pane.show()

	sys.exit(app.exec_())


