# PyQt5 代码结构模板
from PyQt5.Qt import *
from resourse.login import Ui_Form


class LoginPane(QWidget, Ui_Form):
	show_register_pane = pyqtSignal()
	gotocal = pyqtSignal()

	def __init__(self, parent=None, *args, **kwargs):
		super().__init__(parent, *args, **kwargs)  # 用于继承父类
		self.setAttribute(Qt.WA_StyledBackground, True)
		self.setupUi(self)
		# self.setWindowFlags(Qt.FramelessWindowHint)  # 隐藏介面头部
		# 给登录介面头部加一个gif动画********************************************************
		movie = QMovie(':/login/image/leaf.gif')
		movie.setScaledSize(QSize(500, 230))
		self.top_label.setMovie(movie)
		movie.start()

	# 给登录介面头部加一个gif动画********************************************************

	# self.setWindowFlags(Qt.FramelessWindowHint)  # 隐藏介面头部
	def show_registerPane(self):
		self.show_register_pane.emit()

	def go_to_cal(self):
		self.gotocal.emit()


# 设置介面可用鼠标拖动**************************************************************
# 	def mousePressEvent(self, even):
# 		if even.button() == Qt.LeftButton:
# 			self.m_drag = True
# 			self.m_DragPosition = even.globalPos() - self.pos()
# 			even.accept()
# 			self.setCursor(QCursor(Qt.OpenHandCursor))
#
# 	def mouseReleaseEvent(self, even):
# 		if even.button() == Qt.LeftButton:
# 			self.m_drag = False
# 			self.setCursor(QCursor(Qt.ArrowCursor))
#
# 	def mouseMoveEvent(self, even):
# 		if Qt.LeftButton and self.m_drag:
# 			self.move(even.globalPos() - self.m_DragPosition)
# 			even.accept()
# 设置介面可用鼠标拖动**************************************************************

if __name__ == '__main__':
	import sys

	app = QApplication(sys.argv)

	window = LoginPane()

	window.show()

	sys.exit(app.exec_())
