# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'register.ui'
#
# Created by: PyQt5 UI code generator 5.13.0
#
# WARNING! All changes made in this file will be lost!


from PyQt5 import QtCore, QtGui, QtWidgets


class Ui_Form(object):
    def setupUi(self, Form):
        Form.setObjectName("Form")
        Form.resize(500, 451)
        Form.setMinimumSize(QtCore.QSize(500, 451))
        Form.setMaximumSize(QtCore.QSize(500, 450))
        Form.setStyleSheet("QWidget#Form{\n"
"    border-image: url(:/bk/image/register.jpg);\n"
"}")
        self.pushButton_3 = QtWidgets.QPushButton(Form)
        self.pushButton_3.setGeometry(QtCore.QRect(70, 10, 45, 45))
        self.pushButton_3.setStyleSheet("QPushButton{\n"
"   border-radius:22px;\n"
"   background-color:pink;\n"
"   color:rgb(85, 85, 127)\n"
"}\n"
"\n"
"QPushButton:hover{\n"
"   background-color:rgb(242, 221, 244);\n"
"}\n"
"\n"
"QPushButton:checked{\n"
"   background-color:rgb(231, 113, 135);\n"
"}")
        self.pushButton_3.setCheckable(False)
        self.pushButton_3.setObjectName("pushButton_3")
        self.pushButton_4 = QtWidgets.QPushButton(Form)
        self.pushButton_4.setGeometry(QtCore.QRect(10, 10, 45, 45))
        self.pushButton_4.setStyleSheet("QPushButton{\n"
"   border-radius:22px;\n"
"   background-color:pink;\n"
"   color:rgb(85, 85, 127)\n"
"}\n"
"\n"
"QPushButton:hover{\n"
"   background-color:rgb(242, 221, 244);\n"
"}\n"
"\n"
"QPushButton:checked{\n"
"   background-color:rgb(231, 113, 135);\n"
"}")
        self.pushButton_4.setCheckable(False)
        self.pushButton_4.setObjectName("pushButton_4")
        self.pushButton_5 = QtWidgets.QPushButton(Form)
        self.pushButton_5.setGeometry(QtCore.QRect(130, 10, 45, 45))
        self.pushButton_5.setStyleSheet("QPushButton{\n"
"   border-radius:22px;\n"
"   background-color:pink;\n"
"   color:rgb(85, 85, 127)\n"
"}\n"
"\n"
"QPushButton:hover{\n"
"   background-color:rgb(242, 221, 244);\n"
"}\n"
"\n"
"QPushButton:checked{\n"
"   background-color:rgb(231, 113, 135);\n"
"}")
        self.pushButton_5.setCheckable(False)
        self.pushButton_5.setObjectName("pushButton_5")
        self.layoutWidget = QtWidgets.QWidget(Form)
        self.layoutWidget.setGeometry(QtCore.QRect(180, 220, 255, 183))
        self.layoutWidget.setObjectName("layoutWidget")
        self.formLayout = QtWidgets.QFormLayout(self.layoutWidget)
        self.formLayout.setContentsMargins(0, 0, 0, 0)
        self.formLayout.setVerticalSpacing(12)
        self.formLayout.setObjectName("formLayout")
        self.label = QtWidgets.QLabel(self.layoutWidget)
        self.label.setMinimumSize(QtCore.QSize(0, 35))
        self.label.setMaximumSize(QtCore.QSize(16777215, 35))
        self.label.setStyleSheet("color: rgb(255, 0, 0);\n"
"font: 11pt \"黑体\";\n"
"")
        self.label.setObjectName("label")
        self.formLayout.setWidget(0, QtWidgets.QFormLayout.LabelRole, self.label)
        self.accunt_le = QtWidgets.QLineEdit(self.layoutWidget)
        self.accunt_le.setMinimumSize(QtCore.QSize(0, 35))
        self.accunt_le.setMaximumSize(QtCore.QSize(16777215, 35))
        self.accunt_le.setStyleSheet("background-color: transparent;\n"
"border:none;\n"
"border-bottom:1px solid skyblue;")
        self.accunt_le.setText("")
        self.accunt_le.setClearButtonEnabled(True)
        self.accunt_le.setObjectName("accunt_le")
        self.formLayout.setWidget(0, QtWidgets.QFormLayout.FieldRole, self.accunt_le)
        self.label_2 = QtWidgets.QLabel(self.layoutWidget)
        self.label_2.setMinimumSize(QtCore.QSize(0, 35))
        self.label_2.setMaximumSize(QtCore.QSize(16777215, 35))
        self.label_2.setStyleSheet("color: rgb(255, 0, 0);\n"
"font: 11pt \"黑体\";\n"
"")
        self.label_2.setObjectName("label_2")
        self.formLayout.setWidget(1, QtWidgets.QFormLayout.LabelRole, self.label_2)
        self.password_le = QtWidgets.QLineEdit(self.layoutWidget)
        self.password_le.setMinimumSize(QtCore.QSize(0, 35))
        self.password_le.setMaximumSize(QtCore.QSize(16777215, 35))
        self.password_le.setStyleSheet("background-color: transparent;\n"
"border:none;\n"
"border-bottom:1px solid skyblue;")
        self.password_le.setText("")
        self.password_le.setClearButtonEnabled(True)
        self.password_le.setObjectName("password_le")
        self.formLayout.setWidget(1, QtWidgets.QFormLayout.FieldRole, self.password_le)
        self.label_3 = QtWidgets.QLabel(self.layoutWidget)
        self.label_3.setMinimumSize(QtCore.QSize(0, 35))
        self.label_3.setMaximumSize(QtCore.QSize(16777215, 35))
        self.label_3.setStyleSheet("color: rgb(255, 0, 0);\n"
"font: 11pt \"黑体\";\n"
"")
        self.label_3.setObjectName("label_3")
        self.formLayout.setWidget(2, QtWidgets.QFormLayout.LabelRole, self.label_3)
        self.confrim_pw_le = QtWidgets.QLineEdit(self.layoutWidget)
        self.confrim_pw_le.setMinimumSize(QtCore.QSize(0, 35))
        self.confrim_pw_le.setMaximumSize(QtCore.QSize(16777215, 35))
        self.confrim_pw_le.setStyleSheet("background-color: transparent;\n"
"border:none;\n"
"border-bottom:1px solid skyblue;")
        self.confrim_pw_le.setText("")
        self.confrim_pw_le.setClearButtonEnabled(True)
        self.confrim_pw_le.setObjectName("confrim_pw_le")
        self.formLayout.setWidget(2, QtWidgets.QFormLayout.FieldRole, self.confrim_pw_le)
        self.pushButton = QtWidgets.QPushButton(self.layoutWidget)
        self.pushButton.setEnabled(False)
        self.pushButton.setMinimumSize(QtCore.QSize(0, 40))
        self.pushButton.setMaximumSize(QtCore.QSize(16777215, 40))
        self.pushButton.setStyleSheet("QPushButton{\n"
"   background-color: rgb(0, 170, 255);\n"
"   color:rgb(255, 255, 255);\n"
"   border-radius: 10px;\n"
"}\n"
"\n"
"QPushButton:disabled{\n"
"   background-color:rgb(198, 198, 198);\n"
"}\n"
"\n"
"QPushButton:hover{\n"
"   background-color:rgb(255, 170, 127);\n"
"}\n"
"\n"
"QPushButton:pressed{\n"
"   background-color: rgb(0, 170, 255);\n"
"}")
        self.pushButton.setObjectName("pushButton")
        self.formLayout.setWidget(3, QtWidgets.QFormLayout.SpanningRole, self.pushButton)

        self.retranslateUi(Form)
        self.pushButton.clicked.connect(Form.register)
        self.pushButton_5.clicked.connect(Form.about)
        self.pushButton_3.clicked.connect(Form.reset_re)
        self.pushButton_4.clicked.connect(Form.exit_re)
        self.accunt_le.textChanged['QString'].connect(Form.enable_register)
        self.password_le.textChanged['QString'].connect(Form.enable_register)
        self.confrim_pw_le.textChanged['QString'].connect(Form.enable_register)
        QtCore.QMetaObject.connectSlotsByName(Form)

    def retranslateUi(self, Form):
        _translate = QtCore.QCoreApplication.translate
        Form.setWindowTitle(_translate("Form", "register"))
        self.pushButton_3.setText(_translate("Form", "重置"))
        self.pushButton_4.setText(_translate("Form", "退出"))
        self.pushButton_5.setText(_translate("Form", "关于"))
        self.label.setText(_translate("Form", "帐    号："))
        self.label_2.setText(_translate("Form", "密    码："))
        self.label_3.setText(_translate("Form", "确认密码："))
        self.pushButton.setText(_translate("Form", "注册"))
import background_image_rc
