# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'login.ui'
#
# Created by: PyQt5 UI code generator 5.13.0
#
# WARNING! All changes made in this file will be lost!


from PyQt5 import QtCore, QtGui, QtWidgets


class Ui_Form(object):
    def setupUi(self, Form):
        Form.setObjectName("Form")
        Form.resize(500, 450)
        Form.setMinimumSize(QtCore.QSize(500, 450))
        Form.setMaximumSize(QtCore.QSize(500, 450))
        Form.setStyleSheet("")
        self.verticalLayout = QtWidgets.QVBoxLayout(Form)
        self.verticalLayout.setContentsMargins(0, 0, 0, 0)
        self.verticalLayout.setSpacing(0)
        self.verticalLayout.setObjectName("verticalLayout")
        self.widget = QtWidgets.QWidget(Form)
        self.widget.setStyleSheet("")
        self.widget.setObjectName("widget")
        self.horizontalLayout_2 = QtWidgets.QHBoxLayout(self.widget)
        self.horizontalLayout_2.setContentsMargins(0, 0, 0, 0)
        self.horizontalLayout_2.setSpacing(0)
        self.horizontalLayout_2.setObjectName("horizontalLayout_2")
        self.top_label = QtWidgets.QLabel(self.widget)
        self.top_label.setStyleSheet("")
        self.top_label.setFrameShadow(QtWidgets.QFrame.Plain)
        self.top_label.setText("")
        self.top_label.setObjectName("top_label")
        self.horizontalLayout_2.addWidget(self.top_label)
        self.verticalLayout.addWidget(self.widget)
        self.widget_2 = QtWidgets.QWidget(Form)
        self.widget_2.setStyleSheet("")
        self.widget_2.setObjectName("widget_2")
        self.horizontalLayout = QtWidgets.QHBoxLayout(self.widget_2)
        self.horizontalLayout.setContentsMargins(10, 0, 10, 10)
        self.horizontalLayout.setSpacing(0)
        self.horizontalLayout.setObjectName("horizontalLayout")
        self.pushButton = QtWidgets.QPushButton(self.widget_2)
        self.pushButton.setMinimumSize(QtCore.QSize(80, 0))
        self.pushButton.setMaximumSize(QtCore.QSize(80, 16777215))
        self.pushButton.setFlat(True)
        self.pushButton.setObjectName("pushButton")
        self.horizontalLayout.addWidget(self.pushButton, 0, QtCore.Qt.AlignLeft|QtCore.Qt.AlignBottom)
        self.widget_3 = QtWidgets.QWidget(self.widget_2)
        self.widget_3.setStyleSheet("")
        self.widget_3.setObjectName("widget_3")
        self.gridLayout = QtWidgets.QGridLayout(self.widget_3)
        self.gridLayout.setObjectName("gridLayout")
        self.lineEdit = QtWidgets.QLineEdit(self.widget_3)
        self.lineEdit.setMinimumSize(QtCore.QSize(0, 45))
        self.lineEdit.setMaximumSize(QtCore.QSize(16777215, 45))
        self.lineEdit.setStyleSheet("QLineEdit  {\n"
"font-size:20px;\n"
"border:none;\n"
"border-bottom:1px solid lightgray;\n"
"    background-color: transparent;\n"
"}\n"
"QLineEdit:hover  {\n"
"border-bottom:1px solid gray;    \n"
"}\n"
"QLineEdit:focus  {\n"
"border-bottom:1px solid rgb(18,183,245);\n"
"}\n"
"\n"
"\n"
"\n"
"")
        self.lineEdit.setEchoMode(QtWidgets.QLineEdit.PasswordEchoOnEdit)
        self.lineEdit.setClearButtonEnabled(True)
        self.lineEdit.setObjectName("lineEdit")
        self.gridLayout.addWidget(self.lineEdit, 1, 0, 1, 3)
        self.login_btn = QtWidgets.QPushButton(self.widget_3)
        self.login_btn.setMinimumSize(QtCore.QSize(120, 50))
        self.login_btn.setMaximumSize(QtCore.QSize(120, 50))
        self.login_btn.setStyleSheet("QPushButton {\n"
"    background-color: rgb(33,174,250);\n"
"    border-radius:5px;\n"
"    color:white;\n"
"}\n"
"QPushButton:hover {\n"
"    background-color: rgb(72,203,250);\n"
"}\n"
"QPushButton:pressed {\n"
"    background-color: rgb(85,85,255);\n"
"}")
        self.login_btn.setObjectName("login_btn")
        self.gridLayout.addWidget(self.login_btn, 3, 0, 1, 1)
        self.comboBox = QtWidgets.QComboBox(self.widget_3)
        self.comboBox.setMinimumSize(QtCore.QSize(0, 45))
        self.comboBox.setMaximumSize(QtCore.QSize(16777215, 45))
        self.comboBox.setStyleSheet("QComboBox {\n"
"font-size:20px;\n"
"border:none;\n"
"border-bottom:1px solid lightgray;\n"
"background-color:transparent;\n"
"}\n"
"QComboBox:hover {\n"
"border-bottom:1px solid gray;\n"
"}\n"
"QComboBox:focus {\n"
"\n"
"border-bottom:1px solid rgb(85, 170, 0);\n"
"\n"
"}\n"
"QComboBox::drop-down {\n"
"background-color:transparent;\n"
"width:60px;\n"
"height:40px;\n"
"}\n"
"QComboBox::down-arrow {\n"
"image: url(:/login/image/Stacks_closed-alt.ico);\n"
"width:60px;\n"
"height:20px;\n"
"}\n"
"")
        self.comboBox.setEditable(True)
        self.comboBox.setObjectName("comboBox")
        icon = QtGui.QIcon()
        icon.addPixmap(QtGui.QPixmap(":/bk/image/my photo.jpg"), QtGui.QIcon.Normal, QtGui.QIcon.Off)
        self.comboBox.addItem(icon, "")
        icon1 = QtGui.QIcon()
        icon1.addPixmap(QtGui.QPixmap(":/login/image/Stacks_closed-alt.ico"), QtGui.QIcon.Normal, QtGui.QIcon.Off)
        self.comboBox.addItem(icon1, "")
        self.gridLayout.addWidget(self.comboBox, 0, 0, 1, 3)
        self.exit_btn = QtWidgets.QPushButton(self.widget_3)
        self.exit_btn.setMinimumSize(QtCore.QSize(120, 50))
        self.exit_btn.setMaximumSize(QtCore.QSize(120, 50))
        self.exit_btn.setStyleSheet("QPushButton {\n"
"    background-color: rgb(33,174,250);\n"
"    border-radius:5px;\n"
"    color:white;\n"
"}\n"
"QPushButton:hover {\n"
"    background-color: rgb(72,203,250);\n"
"}\n"
"QPushButton:pressed {\n"
"    background-color: rgb(85,85,255);\n"
"}")
        self.exit_btn.setObjectName("exit_btn")
        self.gridLayout.addWidget(self.exit_btn, 3, 2, 1, 1)
        self.checkBox_2 = QtWidgets.QCheckBox(self.widget_3)
        self.checkBox_2.setObjectName("checkBox_2")
        self.gridLayout.addWidget(self.checkBox_2, 2, 2, 1, 1, QtCore.Qt.AlignRight)
        self.checkBox = QtWidgets.QCheckBox(self.widget_3)
        self.checkBox.setObjectName("checkBox")
        self.gridLayout.addWidget(self.checkBox, 2, 0, 1, 1, QtCore.Qt.AlignLeft)
        spacerItem = QtWidgets.QSpacerItem(40, 20, QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Minimum)
        self.gridLayout.addItem(spacerItem, 3, 1, 1, 1)
        self.horizontalLayout.addWidget(self.widget_3)
        self.pushButton_2 = QtWidgets.QPushButton(self.widget_2)
        self.pushButton_2.setMinimumSize(QtCore.QSize(80, 100))
        self.pushButton_2.setMaximumSize(QtCore.QSize(80, 100))
        self.pushButton_2.setStyleSheet("border-image: url(:/bk/image/my photo.jpg);")
        self.pushButton_2.setText("")
        self.pushButton_2.setObjectName("pushButton_2")
        self.horizontalLayout.addWidget(self.pushButton_2, 0, QtCore.Qt.AlignRight|QtCore.Qt.AlignBottom)
        self.horizontalLayout.setStretch(0, 2)
        self.horizontalLayout.setStretch(1, 6)
        self.horizontalLayout.setStretch(2, 2)
        self.verticalLayout.addWidget(self.widget_2)
        self.verticalLayout.setStretch(0, 2)
        self.verticalLayout.setStretch(1, 3)

        self.retranslateUi(Form)
        self.pushButton.clicked.connect(Form.show_registerPane)
        self.exit_btn.clicked.connect(Form.close)
        self.login_btn.clicked.connect(Form.go_to_cal)
        QtCore.QMetaObject.connectSlotsByName(Form)

    def retranslateUi(self, Form):
        _translate = QtCore.QCoreApplication.translate
        Form.setWindowTitle(_translate("Form", "login"))
        self.pushButton.setText(_translate("Form", "注册帐号"))
        self.login_btn.setText(_translate("Form", "安全登录"))
        self.comboBox.setItemText(0, _translate("Form", "12345"))
        self.comboBox.setItemText(1, _translate("Form", "23456"))
        self.exit_btn.setText(_translate("Form", "退出"))
        self.checkBox_2.setText(_translate("Form", "记住密码"))
        self.checkBox.setText(_translate("Form", "自动登录"))
import background_image_rc
