# PyQt5 代码结构模板
from PyQt5.Qt import *
from resourse.calculator import Ui_Form


class Calcul(QObject):
	show_content = pyqtSignal(str)
	show_xxx = pyqtSignal(str)

	def __init__(self, parent):
		super().__init__(parent)
		self.key_models = []  # 存储键位

	def calculate(self):
		if len(self.key_models) > 0 and self.key_models[-1]['role'] == 'orp':
			self.key_models.pop(-1)
		experssion = ''
		for model in self.key_models:
			experssion += model['title']
			self.show_xxx.emit(experssion)

		print(experssion)
		result = eval(experssion)
		return result

	def parse_key_model(self, key_model):
		# print(key_model)

		if key_model['role'] == 'clear':
			self.key_models = []
			self.show_content.emit('0.0')
			self.show_xxx.emit('0.0')
			return None
		if key_model['role'] == 'cal':
			result = self.calculate()
			self.show_content.emit(str(result))
			return None

		if len(self.key_models) == 0:
			if key_model['role'] == 'num':
				if key_model['title'] == '.':
					key_model['title'] = '0.'
				self.key_models.append(key_model)
				# print(self.key_models)
			return None
		if key_model['title'] in ('%', '+/-'):
			if self.key_models[-1]['role'] != 'num':
				return None
			else:
				if key_model['title'] == '%':
					self.key_models[-1]['title'] = str(float(self.key_models[-1]['title']) / 100)
				elif key_model['title'] == '+/-':
					self.key_models[-1]['title'] = str(
						float(self.key_models[-1]['title']) * -1)
			print(self.key_models)
			return None

		if key_model['role'] == self.key_models[-1]['role']:
			if key_model['role'] == 'num':
				if key_model['title'] == '.' and self.key_models[-1]['title'].__contains__('.'):
					return None
				if self.key_models[-1]['title'] != '0':
					self.key_models[-1]['title'] += key_model['title']
				else:
					self.key_models[-1]['title'] = key_model['title']
			if key_model['role'] == 'orp':
				self.key_models[-1]['title'] = key_model['title']

		else:
			if key_model['title'] in ('.', '%', '+/-'):
				return None
			self.key_models.append(key_model)
		# print(self.key_models)


class CalculatorPane(QWidget, Ui_Form):
	show_register_pane = pyqtSignal()

	def __init__(self, parent=None, *args, **kwargs):
		super().__init__(parent, *args, **kwargs)  # 用于继承父类
		self.setAttribute(Qt.WA_StyledBackground, True)
		self.setupUi(self)
		self.calculator = Calcul(self)
		self.calculator.show_content.connect(self.show_content)

		self.calculator.show_xxx.connect(self.show_top)

	def show_top(self, content):
		self.textEdit.setText(content)

	def show_content(self, content):
		self.label.setText(content)

	def key_methd(self, title, role):
		# print(title,role)
		self.calculator.parse_key_model({'title': title, 'role': role})


if __name__ == '__main__':
	import sys

	app = QApplication(sys.argv)

	window = CalculatorPane()

	window.show()

	sys.exit(app.exec_())
